# LAB08
## 2019A7PS0136G


### Compilation

```bash
gcc ./client.c -o ./client.out
```

### Execution

```bash
./client.out https://sstatic.net/stackexchange/img/logos/so/so-logo-med.png
```
